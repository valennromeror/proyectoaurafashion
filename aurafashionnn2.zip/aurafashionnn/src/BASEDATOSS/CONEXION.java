package BASEDATOSS;  // Define el paquete donde se encuentra la clase

// Importación de librerías necesarias para la conexión a MySQL
import java.sql.Connection;     // Clase para manejar la conexión con la base de datos
import java.sql.DriverManager;  // Clase que administra los controladores JDBC
import java.sql.SQLException;   // Clase que maneja excepciones SQL
import javax.swing.JOptionPane; // Clase para mostrar mensajes de error en cuadros de diálogo

public class CONEXION {  // Clase que gestiona la conexión con la base de datos  //componente
    
    // 🔹 Configuración de la conexión a MySQL
    private final String DRIVER = "com.mysql.jdbc.Driver"; // Driver JDBC para MySQL
    private final String URL = "jdbc:mysql://localhost:3306/"; // URL de conexión al servidor MySQL
    private final String DB = "Aurafashionn"; // Nombre de la base de datos a conectar
    private final String USER = "root"; // Usuario de la base de datos
    private final String PASSWORD = ""; // Contraseña de la base de datos (vacía por defecto en XAMPP)

    public Connection cadena; // Objeto que almacenará la conexión con la base de datos
    public static CONEXION instancia; // Instancia única de la clase (Patrón Singleton)

    // 🔹 Constructor privado para evitar que se creen múltiples instancias de la clase (Singleton)
    private CONEXION() {
        this.cadena = null; // Inicializa la conexión como nula
    }

    // 🔹 Método para conectar a la base de datos
    public Connection conectar() {
        try {
            Class.forName(DRIVER); // Carga el driver JDBC en memoria
            this.cadena = DriverManager.getConnection(URL + DB, USER, PASSWORD); // Establece la conexión con MySQL  //LIBRERIA
        } catch (ClassNotFoundException | SQLException e) { // Captura errores si la conexión falla
            JOptionPane.showMessageDialog(null, "Error de conexión: " + e.getMessage()); // Muestra el error en un cuadro de diálogo
            System.exit(0); // Termina la ejecución si hay un error crítico
        }
        return this.cadena; // Retorna la conexión establecida
    }

    // 🔹 Método para cerrar la conexión con la base de datos
    public void desconectar() {
        try {
            if (this.cadena != null) { // Verifica que la conexión exista antes de cerrarla
                this.cadena.close(); // Cierra la conexión //LIBRERIA
            }
        } catch (SQLException e) { // Captura errores al cerrar la conexión
            JOptionPane.showMessageDialog(null, "Error al cerrar conexión: " + e.getMessage()); // Muestra el error en un cuadro de diálogo
        }
    }

    // 🔹 Método para obtener una única instancia de la conexión (Patrón Singleton)
    public synchronized static CONEXION getInstancia() {
        if (instancia == null) { // Si no existe una instancia, la crea
            instancia = new CONEXION();
        }
        return instancia; // Retorna la instancia única de la conexión
    }
}

    

