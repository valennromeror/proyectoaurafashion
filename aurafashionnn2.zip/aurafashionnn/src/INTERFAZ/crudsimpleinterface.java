package INTERFAZ;

// Interfaz genérica con parámetro Tipo generico

import java.util.List;

public interface crudsimpleinterface<T> {
    
    // Listar objetos de tipo Tipo generico que coinciden con el texto
    public List<T> listar(String texto);

    // Insertar un objeto de tipo T, retorna true si es exitoso
    public boolean insertar(T obj);

    // Actualizar un objeto de tipo T, retorna true si es exitoso
    public boolean actualizar(T obj);

    // Desactivar un objeto por su id, retorna true si es exitoso
    public boolean desactivar(int id);

    // Activar un objeto por su id, retorna true si es exitoso
    public boolean activar(int id);

    // Obtener el total de objetos, retorna un entero
    public int total();

    // Verificar si un objeto existe basado en el texto, retorna true si existe
    public boolean existe(String texto);
}
