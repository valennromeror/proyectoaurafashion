package Entidades;

// Importo la clase Logger para poder hacer logs y registrar eventos
import java.util.logging.Logger;

public class usuarios {
    // Defino los atributos del correo y la contraseña como 'final' porque no quiero que cambien después de ser inicializados
    private final String correo;
    private final String contraseña;
    
    // Atributo para saber si el usuario está activo o no, lo inicializo en 'false' por defecto
    private boolean activo;

    // Constructor donde recibo el correo y la contraseña para inicializar los atributos
    public usuarios(int aInt, String correo, boolean aBoolean, String string1,String contraseña) {
        this.correo = correo;
        this.contraseña = contraseña;
    }

    public usuarios() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Método getter para obtener el correo del usuario
    public String getCorreo() {
        return correo;
    }

    // Método getter para obtener la contraseña del usuario
    public String getContraseña() {
        return contraseña;
    }

    // Método estático para devolver el Logger, lo utilizo para registrar eventos de la clase
    public static Logger getLOG() {
        return LOG;
    }

    // Creo un Logger estático para poder registrar eventos de esta clase
    private static final Logger LOG = Logger.getLogger(usuarios.class.getName());

    // Sobrescribo el método toString para representar la información del objeto como una cadena
    @Override
    public String toString() {
        // Devuelvo los valores de los atributos en una cadena para poder ver la información del objeto
        return "usuarios{" + "correo=" + correo + ", contrase\u00f1a=" + contraseña +",activo=" +activo+'}';
    }

    public String getNombre() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public String getDescripcion() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public int getId() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setcontraseña(String contraseña) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setcorreo(String correo) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void setId(int id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
