package negocio;

import datos.usuariosdao;
import Entidades.usuarios;
import java.util.ArrayList;
import java.util.List;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author JcarlosAd7
 */
public class usuarioControl {
    private final usuariosdao DATOS;
    private final usuarios obj;
    private DefaultTableModel modeloTabla;
    public int registrosMostrados;
    
    public usuarioControl(){
        this.DATOS=new usuariosdao();
        this.obj=new usuarios();
        this.registrosMostrados=0;
    }
    
    public DefaultTableModel listar(String texto){
        List<usuarios> lista=new ArrayList();
        lista.addAll(DATOS.listar(texto));
        
        String[] titulos={"Id","correo","contraseña","Estado"};
        this.modeloTabla=new DefaultTableModel(null,titulos);        
        
        String estado;
        String[] registro = new String[4];
        
        this.registrosMostrados=0;
        for (usuarios item:lista){
            if (item.isactivo()){
                estado="activo";
            } else{
                estado="Inactivo";
            }
            registro[0]=Integer.toString(item.getId());
            registro[1]=item.getCorreo();
            registro[2]=item.getContraseña();
            registro[3]=estado;
            this.modeloTabla.addRow(registro);
            this.registrosMostrados=this.registrosMostrados+1;
        }
        return this.modeloTabla;
    }
    
    public String insertar(String correo ,String contraseña){
        if (DATOS.existe(correo)){
            return "El registro ya existe.";
        }else{
            obj.setcorreo(correo);
            obj.setcontraseña(contraseña);
            if (DATOS.insertar(obj)){
                return "OK";
            }else{
                return "Error en el registro.";
            }
        }
    }
    
    public String actualizar(int id, String correo,String correoAnt,String contraseña){
        if (correo.equals(correoAnt)){
            obj.setId(id);
            obj.setcorreo(correo);
            obj.setcontraseña(contraseña);
            if(DATOS.actualizar(obj)){
                return "OK";
            }else{
                return "Error en la actualización.";
            }
        }else{
            if (DATOS.existe(correo)){
                return "El registro ya existe.";
            }else{
                obj.setId(id);
                obj.setcorreo(correo);
                obj.setcontraseña(contraseña);
                if (DATOS.actualizar(obj)){
                    return "OK";
                }else{
                    return "Error en la actualización.";
                }
            }
        }
    }
    
    public String desactivar(int id){
        if (DATOS.desactivar(id)){
            return "OK";
        }else{
            return "No se puede desactivar el registro";
        }
    }
    
    public String activar(int id){
        if (DATOS.activar(id)){
            return "OK";
        }else{
            return "No se puede activar el registro";
        }
    }
    
    public int total(){
        return DATOS.total();
    }
    
    public int totalMostrados(){
        return this.registrosMostrados;
    }
}
